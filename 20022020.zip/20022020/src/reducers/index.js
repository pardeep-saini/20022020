import { combineReducers } from 'redux';
import getAccountDetails from './getDashBoardAccount/getAccountReducer';
import serachResult from './searchAccount/serachAccount';
import routerDetails from './routerDetails/index';
const rootReducer = combineReducers({
  getAccountDetails,
  serachResult,
  routerDetails
});

export default rootReducer;