import * as types from "../../actions/loginWithCloudKeeper/loginWithCloudConstant";


export default function loginWithCloudKeeperReducers(state = [], action) {
    switch (action.type) {
      case types.LOGIN_WITH_CLOUD_KEEPER:
        return { loading: true, ...state };
      default:
        return state;
    }
  }


