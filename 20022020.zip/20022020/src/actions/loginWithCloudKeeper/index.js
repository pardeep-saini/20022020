import { LOGIN_WITH_CLOUD_KEEPER } from "./loginWithCloudConstant";
export const loginWithCloudKeeper = (token='') => {
     const type = LOGIN_WITH_CLOUD_KEEPER;
     return {type, token}
};