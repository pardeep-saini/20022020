import { GET_ACCOUNT_DETAILS,OPEN_ROUTER_SCREEN, DASH_BOARD_DEATILS } from "./getAccountNameConstant";



export const getAccountDetails = (details) => {
    const type = GET_ACCOUNT_DETAILS;
    return {type, details}
};


export const openRouterScreen = (details, row) => {
    const type = OPEN_ROUTER_SCREEN;
    return {type, details, row}
};
export const dashBoardDetails = (details) => {
    const type = DASH_BOARD_DEATILS;
    return {type, details}
};




