const express = require('express');
const router = express.Router();
const userController = require('../controllers/user.controller');
const auth = require('../middleware/auth.middleware');
const Role = require('../utils/userRoles.utils');
const awaitHandlerFactory = require('../middleware/awaitHandlerFactory.middleware');

const { createUserSchema, updateUserSchema, validateLogin } = require('../middleware/validators/userValidator.middleware');


router.get('/', auth(), awaitHandlerFactory(userController.getAllUsers)); // http://localhost:3331/api/v1/cloudkeeper
router.post('/routers',awaitHandlerFactory(userController.getWholeUser)); // http://localhost:3331/api/v1/cloudkeeper
router.get('/dashboard',awaitHandlerFactory(userController.dashboard)); // http://localhost:3331/api/v1/cloudkeeper


module.exports = router;