import React, { useState, useEffect } from "react";
import { BrowserRouter as Router, Link, useLocation } from "react-router-dom";
import jwt_decode from "jwt-decode";
import { makeStyles } from "@material-ui/core/styles";
import Grid from "@material-ui/core/Grid";
import Button from "@material-ui/core/Button";
import axios from "axios";

const useStyles = makeStyles((theme) => ({
  root: {
    flexGrow: 1,
    margin: 50,
  },
  paper: {
    padding: 20,
    textAlign: "center",
    justifyContent: "center",
    color: theme.palette.text.secondary,
    overflowWrap: "break-word",
  },
  paperLeftAlign: {
    padding: 50,
    textAlign: "left",
    color: theme.palette.text.primary,
    overflowWrap: "break-word",
  },
  table: {
    minWidth: 650,
  },
  button: {
    margin: 5,
  },
}));
const REACT_APP_LOGIN_URL="http://localhost:3000/login"
const REACT_APP_LOgOut_URL="http://localhost:3000/logout"
const REACT_APP_OAUTH_CLIENT_ID="24o4j9q2kpfoq17p8r82cr4h5m"
const REACT_APP_OAUTH_CLIENT_SECRET="1e0lqrpbknrqvaqfneua4je29f4v1uk3hbnct2qtugck4hfmh8sm"
const REACT_APP_OAUTH_URL="https://cloudkeeper.auth.eu-west-1.amazoncognito.com"
function useQuery() {
  return new URLSearchParams(useLocation().search);
}

export default function App() {
  return (
    <Router>
      <LoginApp />
    </Router>
  );
}

function LoginApp() {
  const classes = useStyles();
  const [token, setToken] = useState("");
  const [flag, setflag] = useState("1");
  const [code, setCode] = useState("");
  const [userData, setUserData] = useState("");
  let query = useQuery();
  useEffect(() => {
    setCode(query.get("code"));
    var cookieToken = localStorage.getItem("token");
    if (cookieToken != "" && cookieToken != null) {
      setToken(cookieToken);
      setUserData(jwt_decode(cookieToken));
    } else {
      document.getElementById("button").click()
       getToken();
    }


  },

  []);

  const getToken = async() => {
    const config = {
      headers: {
        Authorization:
          "Basic " +
          btoa(
            REACT_APP_OAUTH_CLIENT_ID +
              ":" +
              REACT_APP_OAUTH_CLIENT_SECRET
          ),
        "Content-Type": "application/x-www-form-urlencoded",
      },
    };
    const params = new URLSearchParams(REACT_APP_OAUTH_URL);

    params.append("grant_type", "authorization_code");
    params.append("client_id", REACT_APP_OAUTH_CLIENT_ID);
    params.append("client_secret", REACT_APP_OAUTH_CLIENT_SECRET);
    params.append("code", query.get("code"));

    params.append("redirect_uri", REACT_APP_LOGIN_URL);
    const url = REACT_APP_OAUTH_URL + "/oauth2/token";
    await axios
      .post(url, params, config)
      .then((result) => {
        setToken(result.data.id_token);
        localStorage.setItem("token", result.data.id_token);
        setUserData(jwt_decode(result.data.id_token));
        console.log("result.data.id_token",result.data.id_token)
      })
      .catch((err) => {
        console.log(err);
      });
  };

  return (
    <div className={classes.root}>
      <Grid container spacing={3}>
        {
          localStorage.getItem("token") ? null :  <Button
          id="button"
          className={classes.button}
          href={
            REACT_APP_OAUTH_URL +
            "/login?response_type=code&client_id=" +
            REACT_APP_OAUTH_CLIENT_ID +
            "&redirect_uri=" +
            REACT_APP_LOGIN_URL
          }
          target="_blank"
        />
        }

      </Grid>
    </div>
  );
}
