import React, { Component } from 'react';
import Card from '@material-ui/core/Card';
import CardActions from '@material-ui/core/CardActions';
import CardContent from '@material-ui/core/CardContent';
import Header from '../../components/Header';
import TabPannel from '../../components/Tab';
import { connect } from "react-redux";
import { getAccountDetails } from "../../actions/getDashBoardAccount/getAccountName";
import CloudKeeper from '../../cloudKeeper';
import jwt_decode from "jwt-decode";
import * as S from './Styled';
class Dashboard extends Component {
  constructor(props) {
    super(props);
    this.state = {
      getUserList: [],
      token:'',
      code:'',
      userData:'',
      cloudKeeperFlag:false,
      flag:1
    }


  }

  componentDidMount() {
    this.props.ongetAccountDetails();
    if(!localStorage.getItem('token')) {
      this.interval = setInterval(() => this.setState({ cloudKeeperFlag: true }), 2000);
    } else {
      console.log("TokenVerifying", jwt_decode(`${localStorage.getItem('token')}`))
    }
  }

  componentDidUpdate() {
    console.log("Valued", this.props);
    if(!localStorage.getItem('token')) {
      this.interval = setInterval(() => this.setState({ cloudKeeperFlag: true }), 1000);
    }
    else {
      console.log("TokenVerifying", jwt_decode(`${localStorage.getItem('token')}`))
    }
  }

  render() {

    const { getAccountDetails } = this.props;
    console.log("Valued", this.props);
    return (
      <>
      <Card>
        <CardContent>
          <Header />
        </CardContent>
        <CardActions style={S.customStyles.content}>
          <TabPannel accountDetails={getAccountDetails.data} />
        </CardActions>
      </Card>
      {
        localStorage.getItem('token') ? null : this.state.cloudKeeperFlag ? <CloudKeeper />: null
      }
      </>
    );
  }
}
const mapStateToProps = state => {
  return state;
};

const mapDispatchToProps = {
  ongetAccountDetails: getAccountDetails,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Dashboard);
