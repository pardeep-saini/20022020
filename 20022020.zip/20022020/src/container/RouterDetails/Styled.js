import styled from "styled-components"

export const Container = styled.div`
        padding-left: 3%;
        padding-right: 3%;
        background-color: rgb(242, 242, 242);
`;
export const RouterHead = styled.h3`
        // padding: 6%;
        font-size: 16px;
        font-weight: 500;
        text-align: center;
        cursor: pointer;
        padding-left: 10%;
}
`;
export const Heading = styled.h3`
        height: 6px;
        padding-left: 27px;
}
`;

export const AddSIPProfile = styled.h3`
        margin-left: 78%;
        margin-top: -2%;
`;
export const RouterFooter = styled.h3`
        font-size: 13px;
        font-weight: 600;

        text-align: center;
}
`;
export const RouterValue = styled.h3`
        font-size: 51px;
        font-weight: 500;
        text-align: center;
        margin-top: 10%
}
`;

export const Online = styled.span`
        color: #006400
`;
export const Offline = styled.span`
        color: #8B0000
`;
export const Progress = styled.span`
        color: #fbb713
`;
export const RouterDetails = styled.h3`
        padding-left: 4%;
        font-size: 18px;
`;
export const Table = styled.table`
        border-collapse: separate;
        border-spacing: 0 20px;

`;
export const Tbody = styled.tbody`
        text-align: justify
`;
export const Row = styled.tr`
`;
export const Image = styled.img`
        width: 47%;
`;
export const MessageColor = styled.p`
        color:#e9410c;
`;
export const HeaderTitle = styled.p`
        width: 100%;
        cursor: pointer;
        margin-top: 0%;
`;

export const WifiContainer = styled.div``;
export const WifiTable = styled.table``;
export const WifiTableRow = styled.tr``;
export const WifiTableColume = styled.td``;


export const customStyles = {
        content: {
                marginTop: '33px', backgroundColor: '#f2f2f2'
        },
        paper: {
                width: '200px',

                backgroundColor: '#e5e5e1',
                border: 'none',
        },

        RouterDetails: {
                width: '500px',
                border: 'none',
                borderLeft: '1px solid',
                borderRadius: '0px',
                display: 'flex',
        },
        Tablehead: {
        },

        Router: {
                border: 'none',
                display: 'flex',
        },
        RouterdetailsContainer: {
                backgroundColor: "#e6e5df",
                paddingLeft: '10%',
                paddingRight: '10%'
        },
        MainContainer: {
                backgroundColor: "#e5e5e1",
                // height: '700px'
        },
        Nav: {
        },
        paperSecondRow: {
                width: '470px',
                height: '217px',
        },
        WifiGrid: {
                marginTop: '3%'
        }

};