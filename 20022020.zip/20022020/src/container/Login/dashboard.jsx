import React, { Component } from 'react';
import Card from '@material-ui/core/Card';
import CardActions from '@material-ui/core/CardActions';
import CardContent from '@material-ui/core/CardContent';
import Header from '../../components/Header';
import TabPannel from '../../components/Tab';
import { connect } from "react-redux";
import { loginWithCloudKeeper } from "../../actions/loginWithCloudKeeper";
import * as S from './Styled';
;
class Dashboard extends Component {
  constructor(props) {
    super(props);
    this.state = {
      getUserList: [],
      token:'',
      code:'',
      userData:''
    }
    console.log("TokenVerifying", localStorage.getItem('token'))
  }

  componentDidMount() {
    const {onloginWithCloudKeeper} = this.props;
    onloginWithCloudKeeper(window.location.href)
  }


  render() {
    const { getAccountDetails } = this.props;



    return (
      <>
      <Card>
        <CardContent>
          <Header />
        </CardContent>
        <CardActions style={S.customStyles.content}>
          <TabPannel accountDetails={getAccountDetails.data} />
        </CardActions>
      </Card>
      {/* <CloudKeeper /> */}
      </>
    );
  }
}
const mapStateToProps = state => {
  return state;
};

const mapDispatchToProps = {
  onloginWithCloudKeeper: loginWithCloudKeeper,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Dashboard);
