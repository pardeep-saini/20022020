/**
 * Router screen
 */
export const ROUTER = 'router';
export const CONNECTION = 'connection';
export const WIFI = 'wifi';
export const TOOLS = 'tools';
export const VOIP = 'voip';

/** End */

/**Pie chart */
export const OFFLINE_BY_SUPPLIER = 'Offline By Supplier';
export const ONLINE_BY_SUPPLIER = 'Online By Supplier';
export const DEVICE_TYPE = 'Device Type';

/**End */

/**
 *  Modal Component
 */

export const THREE_SIXTYICON = 'ThreeSixtyIcon';
export const DEVICE_LOG = 'DeviceLog';
export const REBOOT = 'reboot';
export const RESET = 'reset';
export const LOG = 'log';
export const DEVICE_STATISTICS = 'DeviceStatistics';
export const PING_DEVICE = 'pingDivice';



/**
 * End
 */


/**
 * Search by account name
 */
export const ACCOUNT_NAME = 'Account Name';
export const CLIENT_NAME_SERIAL_NUMBER = 'Client Name,Serial Number';



/** End */


/**
 *Dashboard Screeen
 */
export const TOTAL_DEVICES = 'Total Devices';
export const ONLINE_DEVICES = 'Online Devices';
export const OFFLINE_DEVICES = 'Offline Devices';
export const ROUTER_IN_PROGRESS = 'Router In Progress';

/** End */


