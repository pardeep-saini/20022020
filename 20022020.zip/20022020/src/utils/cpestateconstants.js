/**
 *CPE STATE
 */
export const CPE_STATE_UP_TO_DATE = 0; //  No pending properties. The ’properties’ field matches real state of the CPE. The last SetParameterValues call was successfully acknowledged by the CPE
export const CPE_STATE_PENDING = 1; // Pending properties are to be set on the CPE. A standalone configurator process tries to trigger a CWMP connection request on the CPE, setting the state to 2 (CPE_STATE_CONFIGURING).
export const CPE_STATE_CONFIGURING = 2; //  The standalone configurator process made a connection request (CNR) to the CPE. Pending properties are currently set on the CPE, but not yet acknowledged, or a scenario is currently running. The configuration is not completed.
export const CPE_STATE_INITIAL  = 3; // The CPE sent its first inform request to the server and was automatically created in the database.
export const CPE_STATE_NO_REACH_CONFIGURING   = 4;
//The standalone configurator process made a connection request to the CPE but the request failed.
// Note: CNR fails can be detected after significant timeouts, for example socket timeouts and the like. The state is set to 4 only if there was no CPE interaction with the server after the state had been changed to 2 and the failed CNR.
export const CPE_STATE_NO_REACH_UP_TO_DATE  = 5; //The CPE is currently offline but up to date.
// Note: This property makes sense only if the periodic inform is switched on at the CPE, so the server knows when to expect inform calls.
export const CPE_STATE_NO_REACH_PENDING  = 6; // Deprecated
export const CPE_STATE_CONFIGURE_FAILED   = 7; // A TR-069 call like SetParameterValues was carried out but not successfully acknowledged by the CPE. Example: an attempt to set a wrong parameter on the CPE was made.
export const CPE_STATE_FW_DOWNLOADING   = 8; //The CPE is currently downloading a new firmware.
export const CPE_STATE_REBOOT    = 9; //The CPE is currently rebooting.


/** End */
