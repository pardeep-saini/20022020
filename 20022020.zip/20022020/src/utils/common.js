const storage = {
    token: "userToken",
    userInfo: "userInfo",
    userName: "chetu",
    password: "123"
  };
  class User {
    setToken = token => {
      localStorage.setItem(storage.token, token);
    };
    getDataKey = key => {
      return localStorage.getItem(key);
    };
    setUserInfo = info => {
      console.log("Inof::", info)
      localStorage.setItem(storage.userInfo, info);
    };
    isLogin() {
        console.log("UserLogin")
      return localStorage.getItem(storage.token)
        ? true
        : false;
    }

    loginAttemptCloudKeeper = (value='') => {
        console.log("Valuderval", value.token.split('code=')[1]);
      if (value && value.token.split('code=')[1]) {
        this.setToken(value.token.split('code=')[1])
        return true;
      }
      return false;
    };

    clearData() {
      localStorage.removeItem(storage.token);
      localStorage.removeItem(storage.userInfo);
    }
  }
  export default new User();
