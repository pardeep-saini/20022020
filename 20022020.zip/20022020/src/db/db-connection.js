const dotenv = require('dotenv');
dotenv.config();
const mysql2 = require('mysql2');
// const mysql = require('mysql2');

class DBConnection {
    constructor() {
        this.checkConnection();
    }
    checkConnection = () =>{

        const connection = mysql2.createConnection(
            {host:process.env.HOST, user: process.env.DB_USER, database: process.env.DB_DATABASE, port: '4306', password:process.env.DB_PASS}
          );
          connection.connect(function(err) {
            if (err) {
              console.error('Database not connect please check ' + err.stack);
              return;
            }
            console.log('Database connected db id is ' + connection.threadId + '...');
          });

        return connection;
    }

    query = async (sql, values) => {
        return new Promise((resolve, reject) => {
            const callback = (error, result) => {
                if (error) {
                    reject(error);
                    return;
                }
                resolve(result);
            }
            const con = mysql2.createConnection(
                {host:process.env.HOST, user: process.env.DB_USER, database: process.env.DB_DATABASE, port: '4306', password:process.env.DB_PASS}
              );
            con.execute(sql, values, callback);
        }).catch(err => {
            const mysqlErrorList = Object.keys(HttpStatusCodes);
            err.status = mysqlErrorList.includes(err.code) ? HttpStatusCodes[err.code] : err.status;
            throw err;
        });
    }
}

// like ENUM
const HttpStatusCodes = Object.freeze({
    ER_TRUNCATED_WRONG_VALUE_FOR_FIELD: 422,
    ER_DUP_ENTRY: 409
});


// module.exports = new DBConnection().query;
module.exports = new DBConnection().query;