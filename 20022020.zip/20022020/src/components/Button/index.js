import React from "react";
import {Button} from '../../includes';
export const ButtonComponent = (props) => {
    return (
            <Button
            variant={props.variant}
            color={props.color || 'white'}
            onClick = {props.handleChange}
            style={{
                    backgroundColor:'#e9410c',
                    marginLeft: props.margeLeft || '',
                    height:props.height || '',
                    fontSize: '10px',
                    color: props.color
                }}
            > {props.name}
            </Button>
    )
  }