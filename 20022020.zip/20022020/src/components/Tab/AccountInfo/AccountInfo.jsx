import React,{useEffect} from 'react';
import PropTypes from 'prop-types';
import { connect } from "react-redux";
import DashBoardDetails from "../../../container/Dashboard/dashBoardDetails";
import { openRouterScreen, dashBoardDetails } from '../../../actions/getDashBoardAccount/getAccountName'
import * as S from '../Styled';
import {
  Collapse,
  IconButton,
  Table,
  TableBody,
  Paper,
  TableCell,
  TableHead,
  TableRow,
  KeyboardArrowDownIcon,
  KeyboardArrowUpIcon,
  TableContainerMain,
  CircularProgress
} from "../../../includes";
const right = "center";
const mainArray = [
  {
    "id": 1,
    "account": "Invosys Wholesale",
    "routers": "68",
    "routersonline": "50",
    "routersoffline": "10",
    "routersinprogree": "5",
    "quarantine": "3",
    "subAccount": [
      {
        "id": "1",
        "account": "Abc",
        "routers": "68",
        "routersonline": "50",
        "routersoffline": "10",
        "routersinprogree": "5",
        "quaranitine": "3",
      },
      {
        "id": "2",
        "account": "Def",
        "routers": "20",
        "routersonline": "5",
        "routersoffline": "5",
        "routersinprogree": "5",
        "quaranitine": "5",
      }
    ],

  },
  {
    "id": 2,
    "account": "Invosys Wholesale2",
    "routers": "100",
    "routersonline": "50",
    "routersoffline": "30",
    "routersinprogree": "10",
    "quarantine": "10",
    "subAccount": [
      {
        "id": "1",
        "account": "Ghi",
        "routers": "200",
        "routersonline": "50",
        "routersoffline": "50",
        "routersinprogree": "50",
        "quaranitine": "50",
      },
      {
        "id": "2",
        "routers": "300",
        "account": "Jkl",
        "routersonline": "50",
        "routersoffline": "50",
        "routersinprogree": "100",
        "quaranitine": "100",
      }
    ],

  },
  {
    "id": 2,
    "account": "Invosys Wholesale3",
    "routers": "100",
    "routersonline": "50",
    "routersoffline": "30",
    "routersinprogree": "10",
    "quarantine": "10",
    "subAccount": [
      {
        "id": "1",
        "account": "Mno",
        "routers": "200",
        "routersonline": "50",
        "routersoffline": "50",
        "routersinprogree": "50",
        "quaranitine": "50",
      },
      {
        "id": "2",
        "routers": "300",
        "account": "Pqr",
        "routersonline": "50",
        "routersoffline": "50",
        "routersinprogree": "100",
        "quaranitine": "100",
      }
    ],

  },
  {
    "id": 2,
    "account": "Invosys Wholesale4",
    "routers": "100",
    "routersonline": "50",
    "routersoffline": "30",
    "routersinprogree": "10",
    "quarantine": "10",
    "subAccount": [
      {
        "id": "1",
        "account": "Stu",
        "routers": "200",
        "routersonline": "50",
        "routersoffline": "50",
        "routersinprogree": "50",
        "quaranitine": "50",
      },
      {
        "id": "2",
        "account": "Vwx",
        "routers": "300",
        "routersonline": "50",
        "routersoffline": "50",
        "routersinprogree": "100",
        "quaranitine": "100",
      }
    ],

  },


]

function Row(props) {
  let { row, onopenRouterScreen } = props;
  const [open, setOpen] = React.useState(false);
  function getData(event) {
    const result = (row.subAccount).filter(items => items.id == event.target.id);
    onopenRouterScreen(true, result)
  }

  return (
    <React.Fragment>
      <TableRow >
        <TableCell style={S.customStyles.TableCell}>
          <IconButton aria-label="expand row" size="small" onClick={() => setOpen(!open)}>
            {open ? <KeyboardArrowUpIcon /> : <KeyboardArrowDownIcon />}
          </IconButton>
        </TableCell>
        <TableCell component="th" scope="row" key={row.id} style={S.customStyles.TableCellRow}>
          {row.account}
        </TableCell>
        <TableCell align={right} style={S.customStyles.TableCellData}>{row.routers}</TableCell>
        <TableCell align={right} style={S.customStyles.TableCellData}><S.Online>{row.routersonline}</S.Online></TableCell>
        <TableCell align={right} style={S.customStyles.TableCellData}><S.Offline>{row.routersoffline}</S.Offline></TableCell>
        <TableCell align={right} style={S.customStyles.TableCellData}><S.Progress>{row.routersinprogree}</S.Progress></TableCell>
        <TableCell align={right} style={S.customStyles.TableCellData}>{row.quarantine}</TableCell>
      </TableRow>
      <TableRow>
        <TableCell style={{ paddingBottom: 0, paddingTop: 0, paddingLeft: 0, paddingRight: 0 }} colSpan={7}>
          <Collapse in={open} timeout="auto" unmountOnExit>
            <Table size="small" aria-label="purchases">
              <TableBody>
                {row.subAccount.map((items, index) => {
                  return (
                    <TableRow key={items.id} name={items.id} onClick={getData}>
                      <TableCell style={S.customStyles.TableCell} />
                      <TableCell component="th" scope="row" id={items.id} value={"Lorem Ipsum"} style={S.customStyles.TableCellRow}>
                        {items.account}
                      </TableCell>
                      <TableCell align={right} style={S.customStyles.TableCellData}>{items.routers}</TableCell>
                      <TableCell align={right} style={S.customStyles.TableCellData}><S.Online>{items.routersonline}</S.Online></TableCell>
                      <TableCell align={right} style={S.customStyles.TableCellData}><S.Offline>{items.routersoffline}</S.Offline></TableCell>
                      <TableCell align={right} style={S.customStyles.TableCellData}><S.Progress>{items.routersinprogree}</S.Progress></TableCell>
                      <TableCell align={right} style={S.customStyles.TableCellData}>{items.quaranitine}</TableCell>
                    </TableRow>
                  )
                })}
              </TableBody>
            </Table>
          </Collapse>
        </TableCell>
      </TableRow>
    </React.Fragment>
  );
}

Row.propTypes = {
  row: PropTypes.shape({
    calories: PropTypes.number.isRequired,
    carbs: PropTypes.number.isRequired,
    fat: PropTypes.number.isRequired,
    history: PropTypes.arrayOf(
      PropTypes.shape({
        amount: PropTypes.number.isRequired,
        customerId: PropTypes.string.isRequired,
        date: PropTypes.string.isRequired,
      }),
    ).isRequired,
    name: PropTypes.string.isRequired,
    price: PropTypes.number.isRequired,
    protein: PropTypes.number.isRequired,
  }).isRequired,
};


function AccountInfo(props) {
  const { getAccountDetails, getDashboard, ondashBoardDetails } = props;


  return (
    <>
      {getAccountDetails.open ? <DashBoardDetails getDashboard={getDashboard} /> :
        <TableContainerMain component={Paper}>
          <Table aria-label="collapsible table">
            <TableHead>
              <TableRow>
                <TableCell />
                <TableCell>Account</TableCell>
                <TableCell align={right}>Routers</TableCell>
                <TableCell align={right}>Routers
                  <S.ShowDisplayOutlate> (Online)</S.ShowDisplayOutlate>
                </TableCell>
                <TableCell align={right}>Routers
                  <S.ShowDisplayOutlate>(Offline)</S.ShowDisplayOutlate>
                </TableCell>
                <TableCell align={right}>Router
                  <S.ShowDisplayOutlate>(In Progress)</S.ShowDisplayOutlate>
                </TableCell>
                <TableCell align={right}>Quaranitine&nbsp;</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {mainArray && mainArray.length > 0 ? null : <center style={S.customStyles.loaderSyled}>
                <CircularProgress style={S.customStyles.CircularProgress} />
              </center>}
              {mainArray && mainArray.map((row) => (
                <Row key={row.name} row={row} onopenRouterScreen={props.onopenRouterScreen} />
              ))}
            </TableBody>
          </Table>
        </TableContainerMain>}

    </>
  );
}


const mapStateToProps = state => {
  return state;
};

const mapDispatchToProps = {
  onopenRouterScreen: openRouterScreen,
};


export default connect(
  mapStateToProps,
  mapDispatchToProps
)(AccountInfo);
