import { takeLatest, takeEvery } from 'redux-saga/effects';
import { getAccount} from  "./getDashBoardAccount/getAccountSagas";
import { getRouterDetails, getfactoryReset, getRouterReboot, getRouterRestart} from  "./getRouterDetails/getRouterSagas";
import { loginWithCloudKeeperSagas} from  "./loginWithCloudKeeper/index";

import * as typesAccountDetails from '../actions/getDashBoardAccount/getAccountNameConstant';
import * as routerDetails from '../actions/routerDetails/routerDetailsConstant';
import * as loginCloud from '../actions/loginWithCloudKeeper/loginWithCloudConstant';

export default function* watchUserAuthentication() {
  yield takeLatest(typesAccountDetails.GET_ACCOUNT_DETAILS, getAccount);
  yield takeLatest(routerDetails.GET_ROUTERS_DETAILS, getRouterDetails);
  yield takeLatest(routerDetails.GET_FACTORY_RESET, getfactoryReset);
  yield takeLatest(routerDetails.ROUTER_REBOOT, getRouterReboot);
  yield takeLatest(routerDetails.ROUTER_RESTART, getRouterRestart);
  yield takeLatest(loginCloud.LOGIN_WITH_CLOUD_KEEPER, loginWithCloudKeeperSagas);
}

