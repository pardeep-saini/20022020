import { put, call, } from 'redux-saga/effects';
// import * as api from '../utils/api';
import * as types from "../../actions/loginWithCloudKeeper/loginWithCloudConstant"
import User from "../../utils/common";


export function* loginWithCloudKeeperSagas(val) {
  console.log("ValueData_Final");
  try {
    if(User.loginAttemptCloudKeeper(val)) {
       yield put({ type: types.LOGIN_WITH_CLOUD_KEEPER, Success: "Successfully Login", statu: "OK" });
    }
  } catch (error) {
    yield put({ type: types.LOGIN_WITH_CLOUD_KEEPER_ERROR, error: 'getting error' });

  }

}