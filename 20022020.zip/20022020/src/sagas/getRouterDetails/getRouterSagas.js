import { put, call, } from 'redux-saga/effects';
import * as api from '../../utils/api';
import * as types from '../../actions/getDashBoardAccount/getAccountNameConstant'
import * as getRouter from '../../actions/routerDetails/routerDetailsConstant'
export function* getRouterDetails() {
  try {
    let response = "";
      response = yield call(api.post, `/routers`);
      console.log("responseresponse", response)
    yield put({ type: getRouter.GET_ROUTERS_DETAILS_SUCCESS, response });

  } catch (error) {
    let response = "";
    response = yield call(api.post, `/routers`);
    yield put({ type: getRouter.GET_ROUTERS_DETAILS_ERROR, router: response });

  }
}

export function* getfactoryReset() {
  try {
    let response = "";
    var data = {
      "cpeid":"virtualCPE"
      }

      response = yield call(api.post, `/factoryreset`, data);
    yield put({ type: getRouter.GET_FACTORY_RESET_SUCCESS, response });
  } catch (error) {
    yield put({ type: getRouter.GET_FACTORY_RESET_ERROR, error: 'getting error' });

  }
}

export function* getRouterReboot() {
  try {
    let response = "";
    var data = {
      "cpeid":"virtualCPE"
      }

      response = yield call(api.post, `/routerreboot`, data);
      console.log("ResponsedRouterReboot", response);
    yield put({ type: getRouter.ROUTER_REBOOT_SUCCESS, response });
  } catch (error) {
    yield put({ type: getRouter.ROUTER_REBOOT_ERROR, error: 'getting error' });

  }
}


export function* getRouterRestart() {
  try {
    let response = "";
    var data = {
      "cpeid":"virtualCPE"
      }

      response = yield call(api.post, `/routerrestart`, data);
    yield put({ type: getRouter.ROUTER_RESTART_SUCCESS, response });
  } catch (error) {
    yield put({ type: getRouter.ROUTER_RESTART_ERROR, error: 'getting error' });

  }
}