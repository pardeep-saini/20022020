const query = require('../db/db-connection');
const { multipleColumnSet } = require('../utils/common.utils');
const Role = require('../utils/userRoles.utils');
const https = require('https');

class UserModel {
    tableName = 'user';

    find = async (params = {}) => {
        let sql = `SELECT * FROM ${this.tableName}`;

        if (!Object.keys(params).length) {
            return await query(sql);
        }

        const { columnSet, values } = multipleColumnSet(params)
        sql += ` WHERE ${columnSet}`;

        return await query(sql, [...values]);
    }


    getRouterDetails = async (params = {}) => {
        // const sql = `call ${process.env.DB_DATABASE}.GetAllRouters()`;  // Store procedure
        const sql = `SELECT distinct
        c.name ClientName,
        cust.name CustomerName,
        r.thirdpartyrouterid CustomerReference,
        rt.manufacturer Make,
        rt.oui Modal,
        c.clientid,
        cust.customerid CustomerId,
        rs.serialnumber,
        cust.status Status
        FROM tickets1.clients c
        join tickets1.routers r
        on r.clientid=c.clientid
        join tickets1.routersstock rs
        on rs.routersstockid=r.routersstockid
        join tickets1.customers cust
        on cust.customerid=c.customerid
        join tickets1.routertypes rt
        on rt.routertypeid=r.routertypeid
        join tickets1.routerstates rstt
        on rstt.routersstockid=r.routersstockid
        join tickets1.states st
        on st.stateid=rstt.newstate
        where parentid =
        (select customerid from customerusers where user="HemantKumar")
        limit 1000`;
        const { values } = multipleColumnSet(params)
        const result = await query(sql, [...values]);
        return result;
    }

    getDeshboardDetails = async (params = {}) => {
            const sql = `select * from tickets1.customers where customerid =
            (select customerid from tickets1.customerusers where user="PradeepSaini") and deleted = 0`;

            const sql2 =`select * from tickets1.customers where parentid in
            (select customerid from tickets1.customers where customerid =
           (select customerid from tickets1.customerusers where user="PradeepSaini") and deleted = 0)  and deleted = 0`





        const {values } = multipleColumnSet(params)
        const result = await query(sql, [...values]);
        const result2 = await query(sql2, [...values]);
        let Online = 0;
        let Offline = 0;
        let InProgress = 0;
        let TotalRoutes = 0;
        for (let i = 0; i < result.length; i++) {
        if (result[i].status === 1) {
            Online++;
        }  else if(result[i].status === 2) {
            Offline++;
        } else if(result[i].status === 3) {
            InProgress++;
        }
        TotalRoutes = Online + Offline + InProgress;
        }
        let RouterDetails = {
            "TotalRoutes": TotalRoutes,
            "Online":Online,
            "Offline":Offline,
            "InProgress":InProgress
        }
        console.log("ResultData", Online, Offline, InProgress, TotalRoutes)
        result.push([{"Data": result2}])


//         var auth = "Basic " + new Buffer("invosysL3" + ":" + "9kP482ZhMPJDtB4Dq!").toString("base64");
//         var options = {
//             'method': 'get',
//             'hostname': 'gcs-stage.bmit.cz',
//             'path': '/i3Hg80/AXAPI/WS/v1/AX2/Portal/cpe/List',
//             'headers': {
//                 'Authorization': auth,
//                 'Content-Type': 'application/json',
//             }
//         };
//         let dataString = '';
//         const response = await new Promise((resolve, reject) => {
//             const req = https.request(options, function (res) {

//                 res.on('data', invo => {
//                     dataString += invo;

//                     let Online = 0;
//                     let Offline = 0;
//                     let InProgress = 0;
//                     let TotalRoutes = 0;
// // console.log("dataString", dataString[1].cpe.state);
//                     // for (let i = 0; i < dataString.length; i++) {
//                     //     console.log("RouterDetails", dataString[i].cpe.state === 1)
//                     //     // if (dataString[i].cpe.state === 1) {
//                     //     //     Online++;
//                     //     // } else if (dataString[i].cpe.state === 2) {
//                     //     //     Offline++;
//                     //     // } else if (dataString[i].cpe.state === 3) {
//                     //     //     InProgress++;
//                     //     // }
//                     //     TotalRoutes = Online + Offline + InProgress;
//                     // }
//                     // let RouterDetails = {
//                     //     "TotalRoutes": TotalRoutes,
//                     //     "Online": Online,
//                     //     "Offline": Offline,
//                     //     "InProgress": InProgress
//                     // }


//                 });

//                 res.on('end', () => {
//                     resolve({
//                         statusCode: 200,
//                         body: JSON.parse(dataString)
//                     });
//                 });
//             });

//             req.on('error', (e) => {
//                 reject({
//                     statusCode: 500,
//                     body: 'Something went wrong!'
//                 });
//             });


//             //   var postData = JSON.stringify({"CPEIdentifier":{"cpeid":"VirtualCPE1"},"CommandOptions":{},"Parameters":["InternetGatewayDevice.DeviceInfo.UpTime"]});
//             //   req.write(postData);
//             req.end();

//         });






//         // console.log("ResultData", response)












        return result;
    }

    findOne = async (params) => {
        const { columnSet, values } = multipleColumnSet(params)

        const sql = `SELECT * FROM ${this.tableName}
        WHERE ${columnSet}`;

        const result = await query(sql, [...values]);

        // return back the first row (user)
        return result[0];
    }

    create = async ({ username, password, first_name, last_name, email, role = Role.SuperUser, age = 0 }) => {
        const sql = `INSERT INTO ${this.tableName}
        (username, password, first_name, last_name, email, role, age) VALUES (?,?,?,?,?,?,?)`;

        const result = await query(sql, [username, password, first_name, last_name, email, role, age]);
        const affectedRows = result ? result.affectedRows : 0;

        return affectedRows;
    }

    update = async (params, id) => {
        const { columnSet, values } = multipleColumnSet(params)

        const sql = `UPDATE user SET ${columnSet} WHERE id = ?`;

        const result = await query(sql, [...values, id]);

        return result;
    }

    delete = async (id) => {
        const sql = `DELETE FROM ${this.tableName}
        WHERE id = ?`;
        const result = await query(sql, [id]);
        const affectedRows = result ? result.affectedRows : 0;

        return affectedRows;
    }
}

module.exports = new UserModel;