import { put, call, } from 'redux-saga/effects';
import * as api from '../../utils/api';
import * as types from '../../actions/getDashBoardAccount/getAccountNameConstant'


export function* getAccount() {
  let response = "";
  try {



      response = yield call(api.get, `https://jsonplaceholder.typicode.com/users`);

    console.log("DataDefault", response)
    yield put({ type: types.GET_ACCOUNT_DETAILS_SUCCESS, response });


  } catch (error) {

    if(response.length>0) {
      console.log("ErrorConditon", response)
      return
    } else {
      console.log("ErrorConditon", response)
      yield put({ type: types.GET_ACCOUNT_DETAILS_ERROR, error: 'getting error' });
    }


  }
}