import { GET_ROUTERS_DETAILS,GET_ROUTERS_ACTIONS, GET_FACTORY_RESET, ROUTER_REBOOT, ROUTER_RESTART } from "./routerDetailsConstant";

export const getRoutersDetails = (details='') => {
    const type = GET_ROUTERS_DETAILS;
    return {type, details}
};

export const getRoutersActions = (routerAction='') => {
    const type = GET_ROUTERS_ACTIONS;
    return {type, routerAction}
};

export const getfactoryResetActions = () => {
    const type = GET_FACTORY_RESET;
    return {type}
};

export const getRouterRebootActions = () => {
    const type = ROUTER_REBOOT;
    return {type}
};

export const getRouterRestartActions = (data) => {
    const type = ROUTER_RESTART;
    return {type}
};



