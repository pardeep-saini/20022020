import React, { Component } from 'react';
import { connect } from "react-redux";
import Switch from '@material-ui/core/Switch';
import MenuItem from '@material-ui/core/MenuItem';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
import * as S from './Styled'
import { InputField } from '../../components/Input';
import { ButtonComponent } from '../../components/Button';
import {
  Paper,
  Grid
} from "../../includes";

const SSID_CUST_MESSAGE = "Please enter character between 1 to 32.";
const WPA_CUST_MESSAGE = "Please enter character between 1 to 64";

class Wifi extends Component {
  constructor(props) {
    super(props);
    this.state = {
      getUserList: [],
      channelSelection: '',
      ssid: '',
      ssid5GHzMsg: '',
      wpa: '',
      ssidMsg: '',
      wpaMsg: '',
      wpa5GHzMsg: ''
    }
  }

  handleChange = (event) => {
    this.setState({ channelSelection: event.target.value })
  }
  changeHandler = (event) => {
    this.setState({ ssidMsg: '', wpaMsg: '', wpa5GHzMsg: '', ssid5GHzMsg: '' })
    var { value, id } = event.target
    if (id === 'ssid' && value.length >= 32) {
      this.setState({ ssidMsg: SSID_CUST_MESSAGE, ssid: value })
    } else if (id === 'wpa' && value.length >= 64) {
      this.setState({ wpaMsg: WPA_CUST_MESSAGE })
    } else if (id === 'ssid5GHz' && value.length >= 32) {
      this.setState({ ssid5GHzMsg: SSID_CUST_MESSAGE })
    } else if (id === 'wpa5GHz' && value.length >= 64) {
      this.setState({ wpa5GHzMsg: WPA_CUST_MESSAGE })
    }
  }

  handleSubmit = () => {
    const { ssid, wpa } = this.state;
    if (ssid == '') {
      this.setState({ ssidMsg: SSID_CUST_MESSAGE })
    }
  }


  render() {
    const { channelSelection, ssidMsg, wpaMsg, ssid5GHzMsg, wpa5GHzMsg } = this.state;
    return (
      <Grid container spacing={3} style={S.customStyles.RouterdetailsContainer}>
        <Grid item xs={12} style={S.customStyles.Nav}>
          <Grid item xs={12}>
            <Paper variant="outlined" >
              <S.Heading>WiFi - 2.4 Ghz</S.Heading>
            </Paper>
          </Grid>
          <Grid container justify="center" spacing={2} >
            <Grid item xs={12}>
              <Paper style={S.customStyles.Router} variant="outlined" >
                <S.WifiContainer className="wifiBox">
                  <S.WifiTable>
                    <S.WifiTableRow>
                      <S.WifiTableColume>SSID</S.WifiTableColume>
                      <S.WifiTableColume>
                        <InputField
                          id="ssid"
                          label="SSID"
                          type="number"
                          maxLength="32"
                          changeHandler={this.changeHandler}
                        />
                        <S.MessageColor>{ssidMsg || ''}</S.MessageColor>
                      </S.WifiTableColume>
                    </S.WifiTableRow>
                    <S.WifiTableRow>
                      <S.WifiTableColume>WPA</S.WifiTableColume>
                      <S.WifiTableColume>
                        <InputField
                          id="wpa"
                          label="WPA"
                          type="number"
                          maxLength="64"
                          changeHandler={this.changeHandler}
                        />
                        <S.MessageColor>{wpaMsg || ''}</S.MessageColor>
                      </S.WifiTableColume>
                    </S.WifiTableRow>


                    <S.WifiTableRow>
                      <S.WifiTableColume>WiFi-SSID-InvosysACS</S.WifiTableColume>
                      <S.WifiTableColume>
                        <InputField
                          id="standard-basic"
                          label="InvosysACS123456"
                        // changeHandler={this.changeHandler}
                        />
                      </S.WifiTableColume>
                    </S.WifiTableRow>
                    <S.WifiTableRow>
                      <S.WifiTableColume>State</S.WifiTableColume>
                      <S.WifiTableColume> <Switch
                        color="primary"
                        name="checkedB"
                        inputProps={{ 'aria-label': 'primary checkbox' }}
                      /></S.WifiTableColume>
                    </S.WifiTableRow>
                    <S.WifiTableRow>
                      <S.WifiTableColume>Channel</S.WifiTableColume>
                      <S.WifiTableColume>
                        <FormControl>
                          <Select
                            labelId="demo-simple-select-label"
                            id="demo-simple-select"
                            value={channelSelection}
                            displayEmpty
                            onChange={(e) => this.handleChange(e)}
                            inputProps={{ 'aria-label': 'Without label' }}
                          >
                            <MenuItem value="">
                              <em>None</em>
                            </MenuItem>
                            <MenuItem value={10}>Channel1</MenuItem>
                            <MenuItem value={20}>Channel2</MenuItem>
                            <MenuItem value={30}>Channel3</MenuItem>
                          </Select>
                        </FormControl></S.WifiTableColume>
                    </S.WifiTableRow>
                  </S.WifiTable>
                </S.WifiContainer>
                <div class="btnRow">
                  <ButtonComponent
                    variant="contained"
                    color="primary"
                    name="Update"
                    margeLeft="0"
                    height="36px"
                    handleChange={this.handleSubmit}
                  />
                </div>
              </Paper>
            </Grid>


          </Grid>
          <Grid item xs={12} style={S.customStyles.WifiGrid}>
            <Paper variant="outlined" >
              <S.Heading>WiFi - 5 Ghz</S.Heading>
            </Paper>
          </Grid>
          <Grid container justify="center" spacing={2} >

            <Grid item xs={12}>

              <Paper style={S.customStyles.Router} variant="outlined" >
                <S.WifiContainer className="wifiBox">
                  <S.WifiTable>
                    <S.WifiTableRow>
                      <S.WifiTableColume>SSID</S.WifiTableColume>
                      <S.WifiTableColume>
                        <InputField
                          id="ssid5GHz"
                          label="SSID"
                          maxLength="32"
                          changeHandler={this.changeHandler}
                        />
                        <S.MessageColor>{ssid5GHzMsg || ''}</S.MessageColor>
                      </S.WifiTableColume>
                    </S.WifiTableRow>
                    <S.WifiTableRow>
                      <S.WifiTableColume>WPA</S.WifiTableColume>
                      <S.WifiTableColume>
                        <InputField
                          id="wpa5GHz"
                          label="WPA"
                          type="number"
                          maxLength="64"
                          changeHandler={this.changeHandler}
                        />
                        <S.MessageColor>{wpa5GHzMsg || ''}</S.MessageColor>
                      </S.WifiTableColume>
                    </S.WifiTableRow>
                    <S.WifiTableRow>
                      <S.WifiTableColume>WiFi-SSID-InvosysACS</S.WifiTableColume>
                      <S.WifiTableColume>
                        <InputField
                          id="standard-basic"
                          label="InvosysACS123456"
                          changeHandler={this.changeHandler}
                        />
                      </S.WifiTableColume>
                    </S.WifiTableRow>

                    <S.WifiTableRow>
                      <S.WifiTableColume>Band Steering</S.WifiTableColume>
                      <S.WifiTableColume>
                        <Switch
                          onChange={this.handleChange}
                          color="primary"
                          name="checkedB"
                          inputProps={{ 'aria-label': 'primary checkbox' }}
                        />
                      </S.WifiTableColume>
                    </S.WifiTableRow>


                    <S.WifiTableRow>
                      <S.WifiTableColume>State</S.WifiTableColume>
                      <S.WifiTableColume> <Switch
                        color="primary"
                        name="checkedB"
                        inputProps={{ 'aria-label': 'primary checkbox' }}
                      /></S.WifiTableColume>
                    </S.WifiTableRow>
                    <S.WifiTableRow>
                      <S.WifiTableColume>Channel</S.WifiTableColume>
                      <S.WifiTableColume>
                        <FormControl >

                          <Select
                            labelId="demo-simple-select-label"
                            id="demo-simple-select"
                            value={channelSelection}
                            displayEmpty
                            onChange={(e) => this.handleChange(e)}
                            inputProps={{ 'aria-label': 'Without label' }}
                          >
                            <MenuItem value="">
                              <em>None</em>
                            </MenuItem>
                            <MenuItem value={10}>Channel1</MenuItem>
                            <MenuItem value={20}>Channel2</MenuItem>
                            <MenuItem value={30}>Channel3</MenuItem>
                          </Select>
                        </FormControl></S.WifiTableColume>
                    </S.WifiTableRow>
                  </S.WifiTable>
                </S.WifiContainer>
                <div class="btnRow">
                  <ButtonComponent
                    variant="contained"
                    color="primary"
                    name="Update"
                    margeLeft="0"
                    height="36px"
                  />
                </div>


              </Paper>
            </Grid>


          </Grid>
        </Grid>



      </Grid>
    );
  }
}
const mapStateToProps = state => {
  return state;
};

const mapDispatchToProps = {

};


export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Wifi);
