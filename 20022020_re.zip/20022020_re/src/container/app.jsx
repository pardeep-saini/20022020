import React, { Component } from 'react';
import Dashboard from './Dashboard'
import LoginDashboard from './Login';
import DashBoardDetails from './Dashboard/dashBoardDetails'
import RouterDetails from './RouterDetails'
import CloudKeeper from '../cloudKeeper';
import { BrowserRouter, Route, Switch } from "react-router-dom";
import Wrapper from "../components/Wrapper";

const wrapperDashboard = Wrapper(Dashboard);
console.log("wrapperDashboard", wrapperDashboard)
class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      token:''
    }
  }
  componentDidUpdate() {
   this.setState({token:localStorage.getItem('userToken')})
  }

  componentDidUpdate(previousProps, previousState) {
    console.log("previousStatepreviousState", previousState, this.state.token)
    if (previousState.token !== this.state.token) {
      this.setState({token:localStorage.getItem('userToken')})
    }
   }
  componentDidMount() {
    this.setState({token:localStorage.getItem('userToken')})

  }
  render() {
    console.log("PropsHisroret_Tested1", this.state.token);

    return (
        <BrowserRouter>
          <Switch>
            <Route exact path="/login" component={Dashboard} />
            {/* <Route exact path="/login" component={LoginDashboard} /> */}
            <Route exact path="/dashboardDetails" component={DashBoardDetails} />
            <Route exact path="/cloudKeeper" component={CloudKeeper} />
            <Route exact path="/routerdetails" component={RouterDetails} />
          </Switch>
        </BrowserRouter>
    );
  }
}
export default App;