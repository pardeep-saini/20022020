import * as types from "../../actions/routerDetails/routerDetailsConstant";

export default function getAccountDetails(state = [], action) {
  console.log("ActionResposed", action);
  let response = action.response && action.response.data.body.Result;
  switch (action.type) {
    case types.GET_ROUTERS_DETAILS:
      return { loading: true, ...state };
    case types.GET_ROUTERS_DETAILS_ERROR:
      return {loading:true, ...state, action}
      case types.GET_ROUTERS_DETAILS_SUCCESS:
      return {loading:true, ...state,action}
    case types.GET_ROUTERS_ACTIONS:
      return { loading: true, data: action };
    case types.GET_FACTORY_RESET:
      return { loading: true, response }
    case types.GET_FACTORY_RESET_SUCCESS:
      return { loading: true, response }
    case types.ROUTER_REBOOT_SUCCESS:
      return { loading: true, response }
    case types.ROUTER_RESTART_SUCCESS:
        return { loading: true, response }

    default:
      return state;
  }
}



