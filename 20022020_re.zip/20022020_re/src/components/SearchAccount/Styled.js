import styled from "styled-components"
export const MainContainer = styled.div`
      flex: 1;
`;  
;
export const customStyles = {
    serachText: {
        fontSize: '13px'
    },
   
    
  };