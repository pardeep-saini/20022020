import React from "react";
import {TextField} from '../../includes'

export const InputField = (props) => {
  console.log("maxLengthmaxLength", props);
    return (

        <TextField
        id={props.id}
        label={props.label}
        // type={props.type || ''}
        autoFocus={false}
        inputProps={{
          maxLength: props.maxLength,
        }}
        onChange={props.changeHandler}
         />
    )
  }