import styled from "styled-components"

export const Container = styled.div`
        padding-left: 3%;
        padding-right: 3%;
        background-color: rgb(242, 242, 242);
`;
export const MainContainer = styled.div`
      flex: 1;
`;
export const CSVDownload = styled.p`
        font-size: 14px;
        padding: 9%;
`;
export const CSVColor = styled.span`
        background-color: black;
        color: white;
        padding: 6%;
        cursor: pointer;
`;

export const ShowDisplayOutlate = styled.span`
      display: block
`;
export const Online = styled.span`
   color: #006400
`;
export const Offline = styled.span`
   color: #8B0000
`;
export const Progress = styled.span`
   color: #fbb713
`;

export const customStyles = {
        content: {
                paddingLeft: '3%', paddingRight: '3%', backgroundColor: '#f2f2f2'
        },
        serachBar: {
                backgroundColor: 'white', width: '97%', marginLeft: 'auto', marginRight: 'auto'
        },
        serachRouters: {
                backgroundColor: 'white', marginLeft: 'auto', marginRight: 'auto'
        },
        RouterContainer: {
                height: 400, width: '100%', backgroundColor: 'white'
        },
        CSVLink: {
                color: 'white'
        },
        ThreeSixtyIcon: {
                color: '#e88d74',
                cursor: 'pointer'
        },
        WifiIcon: {
                cursor: 'pointer'
        },
        labelStyle: {
                fontSize: '13px', width: '107%'
        },
        loaderSyled: {
                marginLeft: ' 942%'
        },
        TableCell:{
                width: '10%'
        },
        TableCellRow:{
                width: '30%',
                cursor: 'pointer'
        },
        TableCellData:{
                width: '12%'
        },
        CircularProgress:{
                width: '28px', height: '100%'
        }



};