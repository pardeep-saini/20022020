import React, { useState, useEffect } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import * as S from '../Styled';
import { connect } from "react-redux";
import { getRoutersDetails, getRoutersActions, getRouterRestartActions } from '../../../actions/routerDetails/index';
import { CSVLink } from "react-csv";
import { Modal } from '../../../components/Modal';
import {
  Table,
  Box,
  TextField,
  Typography,
  TableBody,
  Grid,
  Search,
  RouterIcon,
  FileCopyIcon,
  WifiIcon,
  FindInPageIcon,
  ThreeSixtyIcon,
  Paper,
  TableRow,
  TableHead,
  TableContainerMain,
  TableCell,
  CircularProgress
} from "../../../includes";
import { useHistory } from 'react-router-dom';


let routerArray = [];

const useStyles = makeStyles({
  table: {
    minWidth: 650,
  },
});





function TabPanel(props) {
  const { children, value, index, ...other } = props;
  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box p={3}>
          <Typography>{children}</Typography>
        </Box>
      )}
    </div>
  );
}


function Routers(props) {
  const data= []
  const routerList = (props.routerDetails.action && props.routerDetails.action.router || '')
  const [getRoutersDetails, setRoutersDetails] = useState();
  const [getOpenModal, setOpenModal] = useState(false);
  const [getTitle, setTitle] = useState('');
  const [getClientName, setClientName] = useState('');
  const [getContant, setContant] = useState();
  const [getButtonCancel, setButtonCancel] = useState('');
  const [getButtonSave, setButtonSave] = useState('');
  const [getHeight, setHeight] = useState('');
  const [getWidth, setWidth] = useState('');
  const [getEvent, setEvent] = useState('');
  const [getActionEvent, setActionEvent] = useState('');
  const history = useHistory();
  const classes = useStyles();
  const { onopenRouterDetails } = props;

  useEffect(() => {
    (async () => {
      console.log("Testdata>>>")
      onopenRouterDetails()
    })();
  }, []);


  routerArray = [];
  let handleChangeSearch;

  handleChangeSearch = event => {
    setRoutersDetails({
      rows: routerList.filter(i =>
        i.ClientName.toLowerCase().includes(event.target.value.toLowerCase()) || i.CustomerReference.toLowerCase().includes(event.target.value.toLowerCase()),
      ),
      routerFilter: true,
    });

    console.log("getRoutersDetailsgetRoutersDetails", getRoutersDetails)
    if (getRoutersDetails && getRoutersDetails.routerFilter) {

      routerArray = getRoutersDetails.rows;
    } else {
      routerArray = routerList
    }

    console.log("routerArrayrouterArrayrouterArray", routerArray)


  };



  function handlePopup(event, data = '') {

    if (event === 'ThreeSixtyIcon') {
      setOpenModal(true);
      setEvent('ThreeSixtyIcon')
      setTitle("Restart Device for ");
      setClientName("ABC");
      setContant("This Router will be restarted , do you want to continue ?");
      setButtonCancel("CANCEL");
      setButtonSave("RESTART");
      setHeight('');
      setWidth('')
    } else if (event === 'DeviceLog') {
      setOpenModal(true);
      setEvent('DeviceLog')
      setTitle("Device Log");
      setClientName("");
      setContant("List the device log details as pulled from the Axiros API.");
      setButtonCancel("CLOSE");
      setButtonSave("Save");
      setHeight('533px');
      setWidth('571px')
    } else if (event === 'DeviceStatistics') {
      setOpenModal(true);
      setEvent('DeviceStatistics')
      setTitle("Device Statistics");
      setButtonCancel("CLOSE");
      setHeight('533px');
      setWidth('571px')
    }
  }

  function redirectHandle(props) {
    props.ongetRoutersActions(true)
    history.push('/routerdetails')
  }
  function handleRouters(data) {

    // let res = routerList.filter(i=> i.CustomerId == data)

    // console.log("DataRouterDetails", res, res)
    history.push('/routerdetails');
  }

  function attributeHandle(event, data = '') {
    setOpenModal(false);
  }

  return (
    <>
      {getOpenModal ?
        <Modal
          open={getOpenModal}
          attributeHandle={(_event, data) => attributeHandle(data)}
          title={getTitle}
          clientName={getClientName}
          contant={getContant}
          buttonCancel={getButtonCancel}
          buttonSave={getButtonSave}
          width={getWidth}
          height={getHeight}
          event={getEvent}
          actionEvent={
            getEvent === 'ThreeSixtyIcon' ? props.ongetRouterRestartActions : null
          }
          responseEvent={props.routerDetails || ''}
        />
        : null}
      <TabPanel style={S.customStyles.serachRouters}>
        <S.MainContainer>
          <Grid container spacing={1} alignItems="flex-end">
            <Grid item>
              <Search />
            </Grid>
            <Grid item>
              <TextField
                id="input-with-icon-grid"
                label={"Client Name"}
                style={S.customStyles.labelStyle}
                onChange={handleChangeSearch}
              />
            </Grid>
          </Grid>


        </S.MainContainer>
      </TabPanel>
      <TabPanel></TabPanel>

      <TableContainerMain component={Paper}>
        <Table className={classes.table} aria-label="simple table">
          <TableHead>
            <TableRow>
              <TableCell>Client</TableCell>
              <TableCell align="center">Customer Reference</TableCell>
              <TableCell align="center">Make&nbsp;/Modal</TableCell>
              <TableCell align="center">Serial Number</TableCell>
              <TableCell align="center">Status</TableCell>
              <TableCell align="center">Quick Action</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
              {routerList && routerList.length>0? null : <CircularProgress style={{ width: '28px', height: '100%', marginLeft: '380%'}} /> }

            {(routerList && routerList.length>0) &&  routerList.map((row) => (

              <TableRow key={row.name}>

                <TableCell
                style={{cursor: 'pointer'}}
                component="th"
                scope="row"
                onClick={(_event, _data) => handleRouters(row.CustomerId)}
                >{row.ClientName}</TableCell>
                <TableCell align="center">{row.CustomerReference}</TableCell>
                <TableCell align="center">{row.Make} /{row.Modal}</TableCell>
                <TableCell align="center">{row.serialnumber}</TableCell>
                <TableCell align="center">{row.Status}</TableCell>
                <TableCell align="center">
                  <ThreeSixtyIcon
                    style={S.customStyles.ThreeSixtyIcon}
                    onClick={(_event, _data) => handlePopup('ThreeSixtyIcon')}
                    value=''
                  />

                  <WifiIcon onClick={(_event, _data) => redirectHandle(props)} style={S.customStyles.WifiIcon} />
                  <FileCopyIcon
                    style={S.customStyles.ThreeSixtyIcon}
                    onClick={(_event, _data) => handlePopup('DeviceLog')}
                  />
                  <FindInPageIcon style={S.customStyles.ThreeSixtyIcon} onClick={(_event, _data) => handlePopup('DeviceStatistics')} />
                  <RouterIcon
                    style={S.customStyles.ThreeSixtyIcon}
                  />
                </TableCell>

              </TableRow>
            ))}
          </TableBody>
          <TableBody><S.CSVDownload>Download <S.CSVColor><CSVLink data={routerList} style={S.customStyles.CSVLink} filename={"Invosys.csv"}>CSV</CSVLink></S.CSVColor></S.CSVDownload></TableBody>
        </Table>
      </TableContainerMain>
    </>
  );
}

const mapStateToProps = state => {
  return state;
};

const mapDispatchToProps = {
  onopenRouterDetails: getRoutersDetails,
  ongetRoutersActions: getRoutersActions,
  ongetRouterRestartActions: getRouterRestartActions
};


export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Routers);
