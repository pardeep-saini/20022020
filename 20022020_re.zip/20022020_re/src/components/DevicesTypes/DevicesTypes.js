import React, { Component } from 'react';
import PieChart from 'wirecase-react-piechart';
import {OFFLINE_BY_SUPPLIER, DEVICE_TYPE} from '../../utils/constants';
import { Grid } from '../../includes';
import * as S from './Styled';

export default class MyComponent extends Component {
    constructor(props, context) {
        super(props, context);
        this.state = {
            expandedSector: null
        };
    }

    handleMouseLeaveFromSector() {
        this.setState({ expandedSector: null });
    }

    render() {
        const { name } = this.props;
        const data = [
            { label: 'Talk Talk', value: 50, color: '#e63d18', rounded: 'rounded' },
            { label: 'BT', value: 100, color: '#3c98fc', rounded: 'rounded' },
        ];

        return (
            <Grid container spacing={2}>
                <Grid item xs={6} sm={3} style={S.customStyles.content}>
                    <S.TypeHeading style={S.customStyles.oflineSuppler}>
                        {name === OFFLINE_BY_SUPPLIER ? OFFLINE_BY_SUPPLIER : DEVICE_TYPE}
                    </S.TypeHeading>
                    {data.map((d, i) => (
                        <S.PieChartContainer>
                            <S.PieChart style={{
                                height: '25px',
                                width: '25px',
                                backgroundColor: i == 0 ? '#ffbbb2' : '#c92d3a',
                                borderRadius: '50%',
                                display: 'inline-block'
                            }}>
                                <S.PieChartP>{d.label}</S.PieChartP></S.PieChart>
                        </S.PieChartContainer>
                    ))}
                </Grid>
                <Grid item xs={6} sm={3} style={S.customStyles.pileChart}>
                    <PieChart
                        data={data}
                        expandedSector={this.state.expandedSector}
                    />
                </Grid>
            </Grid>
        );
    }
}