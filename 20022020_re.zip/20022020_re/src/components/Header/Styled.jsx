import styled from "styled-components"

export const HeaderComponent = styled.header`
`;
export const Section = styled.div`
`;
export const customStyles = {
        header: {
                backgroundColor: "#2b2f30",
                paddingRight: "79px",
                paddingLeft: "118px",
                fontSize: 18
        },

        logo: {
                fontFamily: "Work Sans, sans-serif",
                color: "#FFFEFE",
                textAlign: "left",
        },
        menuButton: {
                size: "18px",
                marginLeft: "-26px",
              },
              toolbar: {
                display: "flex",
                justifyContent: "space-between",
                cursor: 'pointer'
              },
              drawerContainer: {
                padding: "20px 30px",
              },




};