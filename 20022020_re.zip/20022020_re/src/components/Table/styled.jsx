import styled from "styled-components"

export const Container = styled.div`
        padding-left: 3%;
        padding-right: 3%;
        background-color: rgb(242, 242, 242);
`;

export const customStyles = {
        RouterdetailsContainer: {
                backgroundColor: "#e6e5df",
                paddingLeft: '10%',
                paddingRight: '10%'
        },
};